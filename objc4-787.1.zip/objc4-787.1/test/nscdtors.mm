// TEST_CONFIG
// test cdtors, with NSObject instead of TestRoot as the root class

#define USE_FOUNDATION 1
#include "cdtors.mm"

